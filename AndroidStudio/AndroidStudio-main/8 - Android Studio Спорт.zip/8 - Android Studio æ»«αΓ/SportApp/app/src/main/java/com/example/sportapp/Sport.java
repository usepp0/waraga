package com.example.sportapp;

 public class Sport {
     private String name;
     private String description;
     private int imageResourseId;

     private Sport(String name, String description, int imageResourseId) {

         this.name = name;
         this.description = description;
         this.imageResourseId = imageResourseId;
     }

     public static final Sport[] sports = {
             new Sport("Футбол", "Спортивная игра двух команд, " +
                     " состоящая в том, что игроки стараются ударами ноги загнать мяч в ворота противникаю", R.drawable.football_icon),
             new Sport("Волейбол", "Спортивная игра в мяч, перебрасываемой руками через сетку" +
                     "от одной команды к другой.", R.drawable.play_volleyball_icon),
             new Sport("Хоккей", "Командная игра на льду на коньках в небольшой мяч или шайбу, " +
                     "ударяемые клюшкой.", R.drawable.hockey_ice_olympic),
             new Sport("Плавание", "Вид спорта или спортивная дисциплина, заключающаяся в преодолении вплавь за наименьшее время различных дистанций.", R.drawable.swimming_icon),
             new Sport("Теннис", "Спортивная игра маленьким мячом", R.drawable.tennis),
             new Sport("Каратэ", "Спортивная японская борьба", R.drawable.karate),
             new Sport("Бокс", "Кулачный бой в специальных перчатках по определенным правилам " +
                     "между двумя спортсменами", R.drawable.athletic_boxing_exercise_game_sport),

     };

     public String getName() {
         return name;
     }

     public String getDescription() {
         return description;
     }


    public int getImageResourseId(){
        return imageResourseId;
    }

    @Override
    public String toString() {
        return this.name;
    }
}
